# PPB Registry Bruno collection

Open this directory as a collection in Bruno:

```text
docs/bruno/ppb-registry
```

The collection contains two requests:

1. A retail facility search using `Curewave Pharmacy`.
2. A wholesale distributor search using `Abacus Pharma`.

To try another value, change only `search[value]`. Keep the DataTables
parameters in place because the PPB endpoint returns an empty result when the
column metadata is omitted.

Use `ftype: retail` for pharmacies and `ftype: wholesale` for distributors.
The endpoint returns JSON but incorrectly labels it as `text/html`.

If Bruno reports a certificate error, disable SSL certificate verification for
this collection while the PPB host's certificate is invalid.
